# 일본형 시프트·근태·급여 정산 시스템 초기 DB 설계서 (ERD 및 DDL)

## 1. 2인 팀 수직 분할을 고려한 도메인 및 테이블 구성

2인 팀 프로젝트에서 팀원 A(점포·회원·시프트 계획)와 팀원 B(출퇴근 타각·근태 수정·급여 정산)가 충돌 없이 병렬로 개발하려면, 공통 마스터 테이블(`member`, `store`, `store_staff`)을 먼저 고정한 뒤 각자 담당 도메인 테이블을 독립적으로 운영하는 구조가 가장 효율적입니다.

| 

| **구분** | **테이블명 (물리명)** | **테이블명 (논리명)** | **주요 담당** | **핵심 역할 및 설계 의도** | 
| **공통 마스터** | `member` | 회원 | 공통 (A 주도) | Spring Security 로그인 계정 및 권한(`ROLE_OWNER`, `ROLE_STAFF`) 관리 | 
| **공통 마스터** | `store` | 점포 | 공통 (A 주도) | 점주가 운영하는 매장 정보 및 출퇴근 QR 토큰·법정 할증 기준 관리 | 
| **공통 마스터** | `store_staff` | 점포 소속 직원 | 공통 (A 주도) | 점포-알바생 매핑 및 **개인별 시급·왕복 교통비·월 교통비 상한액** 관리 | 
| **시프트 계획 (A)** | `shift_schedule` | 시프트 스케줄 | **팀원 A** | 알바생 희망 시프트 제출(`SUBMITTED`)부터 점주 조율·확정(`CONFIRMED`)까지 일원화 관리 | 
| **근태 실행 (B)** | `attendance` | 출퇴근 기록(타임카드) | **팀원 B** | 당일 출근·퇴근·휴게시간 타각 및 일별 실근무/야간/연장 시간(분 단위) 자동 산출 기록 | 
| **근태 실행 (B)** | `attendance_mod_request` | 근태 수정 요청 | **팀원 B** | 타각 누락·오류 시 알바생이 수정 신청(`PENDING`)하고 점주가 승인(`APPROVED`)/반려(`REJECTED`) | 
| **급여 정산 (B)** | `payroll` | 월별 급여 명세서 | **팀원 B** | 일본 노동기준법 기반 월별 급여(기본급·야간 25%·연장 25%·교통비) 확정 스냅샷 및 엑셀 출력 원본 | 

## 2. 전체 ERD (Entity Relationship Diagram)

```
erDiagram
    MEMBER ||--o{ STORE : "점주 소유 (owner_id)"
    MEMBER ||--o{ STORE_STAFF : "직원 소속 (member_id)"
    STORE ||--o{ STORE_STAFF : "매장 직원 매핑 (store_id)"

    STORE_STAFF ||--o{ SHIFT_SCHEDULE : "희망 제출 및 확정 (store_staff_id)"
    STORE_STAFF ||--o{ ATTENDANCE : "출퇴근 타각 (store_staff_id)"
    STORE_STAFF ||--o{ PAYROLL : "월별 급여 정산 (store_staff_id)"

    SHIFT_SCHEDULE |o--o| ATTENDANCE : "계획 대비 실적 매핑 (shift_id)"
    ATTENDANCE ||--o{ ATTENDANCE_MOD_REQUEST : "근태 수정 요청 (attendance_id)"
    MEMBER ||--o{ ATTENDANCE_MOD_REQUEST : "점주 승인/반려 처리 (reviewer_id)"

```

## 3. 핵심 설계 포인트 (면접 어필 및 개발 편의성)

1. **`store_staff`(점포 소속 직원) 테이블 분리로 다점포·개별 계약 완벽 대응**

   * `member` 테이블에 시급이나 교통비를 바로 넣지 않고 `store_staff` 매핑 테이블에 `hourly_wage`(시급), `daily_transport_fee`(일 왕복 교통비), `monthly_transport_limit`(월 교통비 상한액)을 배치했습니다.

   * 면접 시 \*"알바생이 여러 매장에서 일하거나 매장별로 시급·교통비 계약 조건이 다른 경우를 고려해 회원 인증 정보(`member`)와 근로 계약 정보(`store_staff`)를 정규화하여 분리했습니다"\*라고 어필할 수 있습니다.

2. **희망 시프트와 확정 시프트를 `shift_schedule` 단일 테이블로 통합**

   * 희망 시프트 테이블과 확정 시프트 테이블을 이원화하면 FullCalendar 렌더링 시 JOIN 및 UNION 쿼리가 복잡해집니다.

   * `requested_start_at`/`requested_end_at`(알바생 제출 원본)과 `confirmed_start_at`/`confirmed_end_at`(점주 조율·확정 시간), 그리고 `status`(`SUBMITTED`, `CONFIRMED`, `REJECTED`)를 한 행에 관리하면 **희망 시간 대비 확정 시간 비교 뷰**를 단일 조회로 구현할 수 있습니다.

3. **일본 노동기준법 계산 최적화를 위한 '분(Minute) 단위' 수치 저장**

   * `attendance`와 `payroll`의 근로 시간 컬럼(`work_minutes`, `night_minutes`, `overtime_minutes` 등)은 소수점 오차가 발생하는 `DOUBLE`/`FLOAT` 대신 정수형 분(Minute, `INT`)으로 저장합니다.

   * 급여 계산 시 `시급 × (근무 분 / 60.0)`에 대해 원화/엔화 단수 처리(일본 노동기준법 제24조 통칙상 50전 미만 버림, 50전 이상 반올림 `HALF_UP`)를 일관되게 적용할 수 있습니다.

4. **급여 정산 시점의 계약 조건 스냅샷(`payroll`) 보존**

   * 급여 계산 후 다음 달에 알바생의 시급이 인상되더라도 과거 급여명세서 금액이 바뀌지 않도록, 정산 당시의 `applied_hourly_wage`(적용 시급)를 `payroll` 테이블에 스냅샷으로 함께 저장합니다.

## 4. 테이블별 상세 명세

### 4.1 `member` (회원)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `member_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 회원 고유 식별자 | 
| `email` | `VARCHAR(100)` | `NOT NULL, UNIQUE` | 로그인 ID (이메일) | 
| `password` | `VARCHAR(255)` | `NOT NULL` | BCrypt 암호화 비밀번호 | 
| `name` | `VARCHAR(50)` | `NOT NULL` | 성명 (한자/가나 또는 한글명) | 
| `phone` | `VARCHAR(20)` | `NOT NULL` | 연락처 | 
| `role` | `VARCHAR(20)` | `NOT NULL` | 권한 (`ROLE_OWNER`, `ROLE_STAFF`) | 
| `is_active` | `BOOLEAN` | `NOT NULL DEFAULT TRUE` | 계정 활성화 여부 | 
| `created_at` | `DATETIME` | `NOT NULL` | 가입 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

### 4.2 `store` (점포)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `store_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 점포 고유 식별자 | 
| `owner_id` | `BIGINT` | `FK (member.member_id), NOT NULL` | 점주 회원 ID | 
| `store_name` | `VARCHAR(100)` | `NOT NULL` | 매장명 (예: 도쿄 신주쿠점) | 
| `invite_code` | `VARCHAR(20)` | `NOT NULL, UNIQUE` | 알바생 매장 합류용 초대 코드 | 
| `qr_token` | `VARCHAR(100)` | `NOT NULL` | QR 출퇴근 타각 검증용 토큰 | 
| `open_time` | `TIME` | `NOT NULL DEFAULT '09:00:00'` | 매장 기본 오픈 시간 (캘린더 표시 기준) | 
| `close_time` | `TIME` | `NOT NULL DEFAULT '23:00:00'` | 매장 기본 마감 시간 | 
| `pay_cutoff_day` | `INT` | `NOT NULL DEFAULT 99` | 급여 마감일 (예: 15일, 25일, 말일은 99) | 
| `created_at` | `DATETIME` | `NOT NULL` | 생성 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

### 4.3 `store_staff` (점포 소속 직원 및 근로 계약 조건)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `store_staff_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 점포 직원 매핑 고유 식별자 | 
| `store_id` | `BIGINT` | `FK (store.store_id), NOT NULL` | 소속 점포 ID | 
| `member_id` | `BIGINT` | `FK (member.member_id), NOT NULL` | 알바생 회원 ID | 
| `hourly_wage` | `INT` | `NOT NULL` | 기본 시급 (단위: 엔/원, 예: `1300` - 도쿄 최저임금 1,280엔 이상) | 
| `daily_transport_fee` | `INT` | `NOT NULL DEFAULT 0` | 1일 왕복 교통비 (예: `500`) | 
| `monthly_transport_limit` | `INT` | `NOT NULL DEFAULT 15000` | 월 교통비 지급 상한액 (예: `15000`) | 
| `employment_status` | `VARCHAR(20)` | `NOT NULL DEFAULT 'ACTIVE'` | 재직 상태 (`PENDING`, `ACTIVE`, `RESIGNED`) | 
| `joined_date` | `DATE` | `NOT NULL` | 입사일 | 
| `resigned_date` | `DATE` | `NULL` | 퇴사일 | 
| `created_at` | `DATETIME` | `NOT NULL` | 등록 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

### 4.4 `shift_schedule` (팀원 A: 희망 시프트 제출 및 확정)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `shift_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 시프트 고유 식별자 | 
| `store_id` | `BIGINT` | `FK (store.store_id), NOT NULL` | 점포 ID (점포 전체 캘린더 조회 성능용) | 
| `store_staff_id` | `BIGINT` | `FK (store_staff.store_staff_id), NOT NULL` | 대상 직원 매핑 ID | 
| `work_date` | `DATE` | `NOT NULL` | 근무 기준 일자 (출근 시각 기준 날짜) | 
| `requested_start_at` | `DATETIME` | `NULL` | 알바생 희망 출근 일시 (점주 직접 배정 시 NULL 가능) | 
| `requested_end_at` | `DATETIME` | `NULL` | 알바생 희망 퇴근 일시 (야간 익일 퇴근 대응을 위해 DATETIME 사용) | 
| `confirmed_start_at` | `DATETIME` | `NULL` | 점주 조율·확정 출근 일시 | 
| `confirmed_end_at` | `DATETIME` | `NULL` | 점주 조율·확정 퇴근 일시 | 
| `planned_break_minutes` | `INT` | `NOT NULL DEFAULT 0` | 계획 휴게시간(분) (예: 6시간 초과 시 45분, 8시간 초과 시 60분) | 
| `status` | `VARCHAR(20)` | `NOT NULL DEFAULT 'SUBMITTED'` | 상태 (`SUBMITTED`: 희망제출, `CONFIRMED`: 확정, `REJECTED`: 미배정) | 
| `staff_memo` | `VARCHAR(255)` | `NULL` | 알바생 코멘트 (예: "시험 기간이라 20시까지만 가능") | 
| `owner_memo` | `VARCHAR(255)` | `NULL` | 점주 조율 코멘트 | 
| `created_at` | `DATETIME` | `NOT NULL` | 생성 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

### 4.5 `attendance` (팀원 B: 출퇴근 타각 및 일별 근로시간 산출)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `attendance_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 근태 기록 고유 식별자 | 
| `store_id` | `BIGINT` | `FK (store.store_id), NOT NULL` | 점포 ID | 
| `store_staff_id` | `BIGINT` | `FK (store_staff.store_staff_id), NOT NULL` | 직원 매핑 ID | 
| `shift_id` | `BIGINT` | `FK (shift_schedule.shift_id), NULL` | 연결된 확정 시프트 ID (대타 등 미계획 출근 시 NULL 가능) | 
| `work_date` | `DATE` | `NOT NULL` | 출근 기준 일자 | 
| `clock_in_at` | `DATETIME` | `NOT NULL` | 실제 출근 타각 일시 | 
| `clock_out_at` | `DATETIME` | `NULL` | 실제 퇴근 타각 일시 (근무 중일 때는 NULL) | 
| `break_start_at` | `DATETIME` | `NULL` | 휴게 시작 타각 일시 | 
| `break_end_at` | `DATETIME` | `NULL` | 휴게 종료 타각 일시 | 
| `total_break_minutes` | `INT` | `NOT NULL DEFAULT 0` | 총 휴게시간(분) | 
| `net_work_minutes` | `INT` | `NOT NULL DEFAULT 0` | 실근무시간(분) = `(퇴근 - 출근) - 총 휴게시간` | 
| `night_work_minutes` | `INT` | `NOT NULL DEFAULT 0` | 야간근로시간(분) (`22:00 ~ 익일 05:00` 구간 중 휴게 제외 시간) | 
| `overtime_minutes` | `INT` | `NOT NULL DEFAULT 0` | 연장잔업시간(분) (실근무시간 중 `480분(8시간)` 초과 시간) | 
| `clock_in_method` | `VARCHAR(20)` | `NOT NULL DEFAULT 'BUTTON'` | 타각 방식 (`BUTTON`, `QR`, `MANUAL_APPROVED`) | 
| `attendance_status` | `VARCHAR(20)` | `NOT NULL DEFAULT 'WORKING'` | 근태 상태 (`WORKING`, `ON_BREAK`, `COMPLETED`, `MOD_REQUESTED`) | 
| `created_at` | `DATETIME` | `NOT NULL` | 생성 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

### 4.6 `attendance_mod_request` (팀원 B: 근태 수정 요청 및 승인 워크플로우)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `mod_request_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 근태 수정 요청 고유 식별자 | 
| `attendance_id` | `BIGINT` | `FK (attendance.attendance_id), NULL` | 대상 근태 기록 ID (타각 완전 누락 사후 생성 시 NULL 허용) | 
| `store_id` | `BIGINT` | `FK (store.store_id), NOT NULL` | 점포 ID (사후 신규 생성 시 필수) | 
| `store_staff_id` | `BIGINT` | `FK (store_staff.store_staff_id), NOT NULL` | 요청 알바생 매핑 ID | 
| `work_date` | `DATE` | `NOT NULL` | 근무 기준일 (사후 신규 생성 시 필수) | 
| `before_clock_in_at` | `DATETIME` | `NULL` | 변경 전 출근 일시 (사후 신규 생성 시 NULL 허용) | 
| `before_clock_out_at` | `DATETIME` | `NULL` | 변경 전 퇴근 일시 | 
| `before_break_minutes` | `INT` | `NOT NULL DEFAULT 0` | 변경 전 휴게시간(분) | 
| `requested_clock_in_at` | `DATETIME` | `NOT NULL` | 수정 요청 출근 일시 | 
| `requested_clock_out_at` | `DATETIME` | `NOT NULL` | 수정 요청 퇴근 일시 | 
| `requested_break_minutes` | `INT` | `NOT NULL DEFAULT 0` | 수정 요청 휴게시간(분) | 
| `reason` | `VARCHAR(500)` | `NOT NULL` | 알바생 수정 요청 사유 (예: "마감 청소 후 퇴근 버튼을 깜빡했습니다") | 
| `approval_status` | `VARCHAR(20)` | `NOT NULL DEFAULT 'PENDING'` | 승인 상태 (`PENDING`: 대기, `APPROVED`: 승인, `REJECTED`: 반려) | 
| `reviewer_id` | `BIGINT` | `FK (member.member_id), NULL` | 승인/반려 처리한 점주 ID | 
| `reject_reason` | `VARCHAR(500)` | `NULL` | 점주 반려 사유 | 
| `reviewed_at` | `DATETIME` | `NULL` | 승인/반려 처리 일시 | 
| `created_at` | `DATETIME` | `NOT NULL` | 요청 생성 일시 | 

### 4.7 `payroll` (팀원 B: 일본 노동기준법 월별 급여 정산)

| **컬럼명** | **데이터 타입** | **제약 조건** | **설명** | 
| `payroll_id` | `BIGINT` | `PK, AUTO_INCREMENT` | 급여 정산 고유 식별자 | 
| `store_id` | `BIGINT` | `FK (store.store_id), NOT NULL` | 점포 ID | 
| `store_staff_id` | `BIGINT` | `FK (store_staff.store_staff_id), NOT NULL` | 직원 매핑 ID | 
| `target_year_month` | `CHAR(7)` | `NOT NULL` | 귀속 연월 (예: `'2026-10'`) | 
| `work_days_count` | `INT` | `NOT NULL DEFAULT 0` | 총 출근 일수 (교통비 산정 기준) | 
| `total_work_minutes` | `INT` | `NOT NULL DEFAULT 0` | 월 총 실근무시간(분) | 
| `total_night_minutes` | `INT` | `NOT NULL DEFAULT 0` | 월 총 야간근로시간(분, 22:00\~05:00) | 
| `total_overtime_minutes` | `INT` | `NOT NULL DEFAULT 0` | 월 총 연장근로시간(분, 1일 8시간 초과분) | 
| `applied_hourly_wage` | `INT` | `NOT NULL` | 정산 시점 적용 기본 시급 스냅샷 | 
| `base_pay` | `INT` | `NOT NULL DEFAULT 0` | 기본급 (`총 실근무시간(분) / 60 × 시급`) | 
| `night_allowance` | `INT` | `NOT NULL DEFAULT 0` | 야간 근로 할증 수당 (`야간시간(분) / 60 × 시급 × 0.25`) | 
| `overtime_allowance` | `INT` | `NOT NULL DEFAULT 0` | 연장 잔업 할증 수당 (`연장시간(분) / 60 × 시급 × 0.25`) | 
| `transport_allowance` | `INT` | `NOT NULL DEFAULT 0` | 교통비 (`MIN(출근일수 × 일왕복교통비, 월상한액)`) | 
| `gross_pay` | `INT` | `NOT NULL DEFAULT 0` | 총 지급액 (`기본급 + 야간수당 + 연장수당 + 교통비`) | 
| `payroll_status` | `VARCHAR(20)` | `NOT NULL DEFAULT 'DRAFT'` | 정산 상태 (`DRAFT`: 가계산, `CONFIRMED`: 확정, `PAID`: 지급완료) | 
| `confirmed_at` | `DATETIME` | `NULL` | 급여 확정 일시 | 
| `created_at` | `DATETIME` | `NOT NULL` | 생성 일시 | 
| `updated_at` | `DATETIME` | `NOT NULL` | 수정 일시 | 

## 5. 초기 구축용 SQL DDL 스크립트 (MySQL 8.0 / H2 호환)

아래 스크립트를 `src/main/resources/db/schema.sql`에 저장하여 바로 사용할 수 있습니다.

```
-- 1. 회원 (점주 및 알바생)
CREATE TABLE member (
    member_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '회원 PK',
    email VARCHAR(100) NOT NULL UNIQUE COMMENT '로그인 이메일',
    password VARCHAR(255) NOT NULL COMMENT 'BCrypt 암호화 비밀번호',
    name VARCHAR(50) NOT NULL COMMENT '이름',
    phone VARCHAR(20) NOT NULL COMMENT '연락처',
    role VARCHAR(20) NOT NULL COMMENT '권한 (ROLE_OWNER, ROLE_STAFF)',
    is_active BOOLEAN NOT NULL DEFAULT TRUE COMMENT '계정 활성화 여부',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 점포
CREATE TABLE store (
    store_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '점포 PK',
    owner_id BIGINT NOT NULL COMMENT '점주 회원 FK',
    store_name VARCHAR(100) NOT NULL COMMENT '매장명',
    invite_code VARCHAR(20) NOT NULL UNIQUE COMMENT '직원 등록용 초대 코드',
    qr_token VARCHAR(100) NOT NULL COMMENT 'QR 출퇴근 인증 토큰',
    open_time TIME NOT NULL DEFAULT '09:00:00' COMMENT '기본 오픈 시간',
    close_time TIME NOT NULL DEFAULT '23:00:00' COMMENT '기본 마감 시간',
    pay_cutoff_day INT NOT NULL DEFAULT 99 COMMENT '급여 마감일 (99=말일)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_store_owner FOREIGN KEY (owner_id) REFERENCES member (member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 점포 소속 직원 (근로 계약 및 시급/교통비 기준)
CREATE TABLE store_staff (
    store_staff_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '점포 직원 매핑 PK',
    store_id BIGINT NOT NULL COMMENT '점포 FK',
    member_id BIGINT NOT NULL COMMENT '직원 회원 FK',
    hourly_wage INT NOT NULL COMMENT '기본 시급(엔/원)',
    daily_transport_fee INT NOT NULL DEFAULT 0 COMMENT '1일 왕복 교통비',
    monthly_transport_limit INT NOT NULL DEFAULT 15000 COMMENT '월 교통비 상한액',
    employment_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' COMMENT '재직상태 (PENDING, ACTIVE, RESIGNED)',
    joined_date DATE NOT NULL COMMENT '입사일',
    resigned_date DATE NULL COMMENT '퇴사일',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_store_member UNIQUE (store_id, member_id),
    CONSTRAINT fk_staff_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_staff_member FOREIGN KEY (member_id) REFERENCES member (member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 시프트 스케줄 (팀원 A: 희망 제출 및 확정)
CREATE TABLE shift_schedule (
    shift_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '시프트 PK',
    store_id BIGINT NOT NULL COMMENT '점포 FK',
    store_staff_id BIGINT NOT NULL COMMENT '점포 직원 FK',
    work_date DATE NOT NULL COMMENT '근무 기준일',
    requested_start_at DATETIME NULL COMMENT '희망 출근 일시',
    requested_end_at DATETIME NULL COMMENT '희망 퇴근 일시',
    confirmed_start_at DATETIME NULL COMMENT '확정 출근 일시',
    confirmed_end_at DATETIME NULL COMMENT '확정 퇴근 일시',
    planned_break_minutes INT NOT NULL DEFAULT 0 COMMENT '계획 휴게시간(분)',
    status VARCHAR(20) NOT NULL DEFAULT 'SUBMITTED' COMMENT '상태 (SUBMITTED, CONFIRMED, REJECTED)',
    staff_memo VARCHAR(255) NULL COMMENT '알바생 메모',
    owner_memo VARCHAR(255) NULL COMMENT '점주 메모',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_shift_store_date (store_id, work_date),
    INDEX idx_shift_staff_date (store_staff_id, work_date),
    CONSTRAINT fk_shift_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_shift_staff FOREIGN KEY (store_staff_id) REFERENCES store_staff (store_staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. 출퇴근 근태 기록 (팀원 B: 타임카드 및 일별 시간 산출)
CREATE TABLE attendance (
    attendance_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '근태 PK',
    store_id BIGINT NOT NULL COMMENT '점포 FK',
    store_staff_id BIGINT NOT NULL COMMENT '점포 직원 FK',
    shift_id BIGINT NULL COMMENT '연결된 확정 시프트 FK (미계획 출근 시 NULL)',
    work_date DATE NOT NULL COMMENT '출근 기준일',
    clock_in_at DATETIME NOT NULL COMMENT '출근 타각 일시',
    clock_out_at DATETIME NULL COMMENT '퇴근 타각 일시',
    break_start_at DATETIME NULL COMMENT '휴게 시작 일시',
    break_end_at DATETIME NULL COMMENT '휴게 종료 일시',
    total_break_minutes INT NOT NULL DEFAULT 0 COMMENT '총 휴게시간(분)',
    net_work_minutes INT NOT NULL DEFAULT 0 COMMENT '실근무시간(분, 휴게 제외)',
    night_work_minutes INT NOT NULL DEFAULT 0 COMMENT '야간근로시간(분, 22:00~05:00)',
    overtime_minutes INT NOT NULL DEFAULT 0 COMMENT '연장잔업시간(분, 1일 8시간 초과분)',
    clock_in_method VARCHAR(20) NOT NULL DEFAULT 'BUTTON' COMMENT '타각 방식 (BUTTON, QR, MANUAL_APPROVED)',
    attendance_status VARCHAR(20) NOT NULL DEFAULT 'WORKING' COMMENT '상태 (WORKING, ON_BREAK, COMPLETED, MOD_REQUESTED)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_att_store_date (store_id, work_date),
    INDEX idx_att_staff_date (store_staff_id, work_date),
    CONSTRAINT fk_att_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_att_staff FOREIGN KEY (store_staff_id) REFERENCES store_staff (store_staff_id),
    CONSTRAINT fk_att_shift FOREIGN KEY (shift_id) REFERENCES shift_schedule (shift_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. 근태 수정 요청 (팀원 B: 타각 누락/오류 수정 및 점주 승인)
CREATE TABLE IF NOT EXISTS attendance_mod_request (
    mod_request_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '근태 수정 요청 PK',
    attendance_id BIGINT NULL COMMENT '대상 근태 FK (타각 완전 누락 사후 생성 시 NULL 허용)',
    store_id BIGINT NOT NULL COMMENT '점포 FK (사후 신규 생성 시 필수)',
    store_staff_id BIGINT NOT NULL COMMENT '요청 직원 FK',
    work_date DATE NOT NULL COMMENT '근무 기준일 (사후 신규 생성 시 필수)',
    before_clock_in_at DATETIME NULL COMMENT '수정 전 출근 일시 (사후 신규 생성 시 NULL 허용)',
    before_clock_out_at DATETIME NULL COMMENT '수정 전 퇴근 일시',
    before_break_minutes INT NOT NULL DEFAULT 0 COMMENT '수정 전 휴게시간(분)',
    requested_clock_in_at DATETIME NOT NULL COMMENT '수정 요청 출근 일시',
    requested_clock_out_at DATETIME NOT NULL COMMENT '수정 요청 퇴근 일시',
    requested_break_minutes INT NOT NULL DEFAULT 0 COMMENT '수정 요청 휴게시간(분)',
    reason VARCHAR(500) NOT NULL COMMENT '수정 요청 사유',
    approval_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT '상태 (PENDING, APPROVED, REJECTED)',
    reviewer_id BIGINT NULL COMMENT '승인/반려 처리한 점주 회원 FK',
    reject_reason VARCHAR(500) NULL COMMENT '반려 사유',
    reviewed_at DATETIME NULL COMMENT '승인/반려 처리 일시',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mod_attendance FOREIGN KEY (attendance_id) REFERENCES attendance (attendance_id),
    CONSTRAINT fk_mod_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_mod_staff FOREIGN KEY (store_staff_id) REFERENCES store_staff (store_staff_id),
    CONSTRAINT fk_mod_reviewer FOREIGN KEY (reviewer_id) REFERENCES member (member_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. 월별 급여 정산 (팀원 B: 일본 노동기준법 계산 결과 및 엑셀 출력 원본)
CREATE TABLE payroll (
    payroll_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '급여 정산 PK',
    store_id BIGINT NOT NULL COMMENT '점포 FK',
    store_staff_id BIGINT NOT NULL COMMENT '점포 직원 FK',
    target_year_month CHAR(7) NOT NULL COMMENT '귀속 연월 (YYYY-MM)',
    work_days_count INT NOT NULL DEFAULT 0 COMMENT '총 출근 일수',
    total_work_minutes INT NOT NULL DEFAULT 0 COMMENT '월 총 실근무시간(분)',
    total_night_minutes INT NOT NULL DEFAULT 0 COMMENT '월 총 야간근로시간(분)',
    total_overtime_minutes INT NOT NULL DEFAULT 0 COMMENT '월 총 연장근로시간(분)',
    applied_hourly_wage INT NOT NULL COMMENT '정산 시점 기본 시급 스냅샷',
    base_pay INT NOT NULL DEFAULT 0 COMMENT '기본급 (실근무시간 기준)',
    night_allowance INT NOT NULL DEFAULT 0 COMMENT '야간 근로 할증 수당 (25% 가산분)',
    overtime_allowance INT NOT NULL DEFAULT 0 COMMENT '연장 잔업 할증 수당 (25% 가산분)',
    transport_allowance INT NOT NULL DEFAULT 0 COMMENT '교통비 지급액 (월 상한액 적용 후)',
    gross_pay INT NOT NULL DEFAULT 0 COMMENT '총 지급액',
    payroll_status VARCHAR(20) NOT NULL DEFAULT 'DRAFT' COMMENT '상태 (DRAFT, CONFIRMED, PAID)',
    confirmed_at DATETIME NULL COMMENT '정산 확정 일시',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_payroll_staff_month UNIQUE (store_staff_id, target_year_month),
    CONSTRAINT fk_payroll_store FOREIGN KEY (store_id) REFERENCES store (store_id),
    CONSTRAINT fk_payroll_staff FOREIGN KEY (store_staff_id) REFERENCES store_staff (store_staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

```

## 6. 시급·수당 중복 가산(야간+연장) 처리 규칙 정리 (팀원 B 구현 팁)

일본 노동기준법(제37조)에 따라 기본 시급(100%)을 먼저 `total_work_minutes`(전체 실근무시간)에 대해 계산한 뒤, 할증분(25%만)을 각각 별도 항목으로 더하면 야간이면서 동시에 8시간을 초과한 구간(총 150% 지급 대상)도 수식 충돌 없이 정확하게 계산됩니다.

* **기본급(`base_pay`)**: `ROUND(total_work_minutes / 60.0 * applied_hourly_wage)` (100% 구간 전체 반영)

* **야간 수당(`night_allowance`)**: `ROUND(total_night_minutes / 60.0 * applied_hourly_wage * 0.25)` (야간 25% 가산분만 별도 합산)

* **연장 수당(`overtime_allowance`)**: `ROUND(total_overtime_minutes / 60.0 * applied_hourly_wage * 0.25)` (연장 25% 가산분만 별도 합산)

* **교통비(`transport_allowance`)**: `MIN(work_days_count * daily_transport_fee, monthly_transport_limit)`

* **총 지급액(`gross_pay`)**: `base_pay + night_allowance + overtime_allowance + transport_allowance`