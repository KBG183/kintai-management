[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$expectedHash = "08A492EF1BD7283F1179CD36B948AC5D9F32A39A42DB0CED42A05DC7F0E6D954"

$filePath = "c:\dev\kintai\docs\portfolio_audit_evidence.md"
$content = [System.IO.File]::ReadAllText($filePath, [System.Text.Encoding]::UTF8)

$marker = "### 【Sprint Day 7: 2026-11-10】"
$idx = $content.IndexOf($marker)

if ($idx -lt 0) {
    Write-Error "Marker not found!"
    exit 1
}

$slice = $content.Substring(0, $idx)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$bytes = [System.Text.Encoding]::UTF8.GetBytes($slice)
$actualHash = [System.BitConverter]::ToString($sha256.ComputeHash($bytes)).Replace("-", "")

Write-Output "SLICE_LENGTH_CHARS: $($slice.Length)"
Write-Output "SLICE_LENGTH_BYTES: $($bytes.Length)"
Write-Output "EXPECTED_HASH:      $expectedHash"
Write-Output "ACTUAL_HASH:        $actualHash"
Write-Output "PERFECT_MATCH:      $($expectedHash -eq $actualHash)"
