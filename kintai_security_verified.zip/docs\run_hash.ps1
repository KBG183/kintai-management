$expected = '08A492EF1BD7283F1179CD36B948AC5D9F32A39A42DB0CED42A05DC7F0E6D954'
$txt = [System.IO.File]::ReadAllText('c:/dev/kintai/docs/portfolio_audit_evidence.md', [System.Text.Encoding]::UTF8)
$m = '### 【Sprint Day 7: 2026-11-10】'
$i = $txt.IndexOf($m)
$sub = $txt.Substring(0, $i)
$sha = [System.Security.Cryptography.SHA256]::Create()
$b = [System.Text.Encoding]::UTF8.GetBytes($sub)
$h = [System.BitConverter]::ToString($sha.ComputeHash($b)).Replace('-', '')
[System.Console]::WriteLine('EXPECTED: ' + $expected)
[System.Console]::WriteLine('ACTUAL:   ' + $h)
[System.Console]::WriteLine('MATCH:    ' + ($expected -eq $h))
